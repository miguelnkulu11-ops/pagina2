# The Food Pangea

Sitio estático (HTML + Tailwind por CDN). Sin build.

Publicar en Vercel: importar el repo, Framework Preset "Other", Deploy.
